# Changelog

## 2.2

- Set delay to zero when it is empty (to not break existing configurations) (bugfix)

## 2.1

- Set delay to zero when it is empty (to not break existing configurations)
- Update from bash to bashio

## 2.0

- New option to delay shutting down the Windows PC
- New option to send a message to the PC that is about to be shut down. If somebody is using the PC, you can warn them to save their work.

## 1.0

- Update samba 4.8.8
