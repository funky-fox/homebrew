# Changelog

## 1.3.0

- Add NTP server configuration option.

## 1.2

- Fixes crash when using FQDN as domain

## 1.1

- Rewrite add-on onto Bashio
- Added documentation to add-on repository
- Small changes to code styling

## 1.0

- Update DHCP to 4.4.1
