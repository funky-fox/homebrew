# Changelog

## 1.2.0
- Update to Debian bullseye

## 1.1.1

- Fix aarch64 support

## 1.1.0

- Renaming Home Assistant
- Convert to s6-overlay
- Support new audio backend

## 1.0.0

- Support aarch64 in armv7 combat mode

## 0.9.0

- Corrected link to documentation inside the add-on
- Adjust source links in Dockerfile
- Update add-on documentation to match current state

## 0.8.0

- Fix API url for access to Home Assistant

## 0.7.0

- Add missing options

## 0.6.0

- Update Ada to 0.7
- Add options to change TTS / STT Home Assistant provider

## 0.5.0

- Update Ada to 0.6

## 0.4.0

- Update Ada to 0.5

## 0.3.0

- Update Ada to 0.4

## 0.2.0

- Update Ada to 0.3
- Add armhf support

## 0.1.0

- Initial support
