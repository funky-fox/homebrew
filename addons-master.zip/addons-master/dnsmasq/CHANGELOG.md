# Changelog

## 1.4.4

- Make it align to our base profile

## 1.4.3

- Fix signal handling

## 1.4.2

- Second run for AppArmor profile

## 1.4.1

- Fix AppArmor profile

## 1.4.0

- Adds support for srv-host records

## 1.3.0

- Rewrites add-on onto Bashio
- Adds README to add-on repository
- Some small code formatting

## 1.2.0

- Update DNSmasq 2.80

## 1.1.0

- Add AppArmor profile
