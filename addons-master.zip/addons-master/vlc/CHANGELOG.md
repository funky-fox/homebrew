# Changelog

## 0.1.3

- Correct port on discovery

## 0.1.2

- Revert restart nginx service on error

## 0.1.1

- Restart nginx service on error

## 0.1.0

- Inital release
