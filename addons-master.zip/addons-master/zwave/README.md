# Home Assistant Add-on: OpenZWave

**WARNING: This add-on is deprecated. We recommend using the [Z-Wave JS
add-on](/zwave_js/README.md) along with its integration. The OpenZWave
add-on will no longer receive any updates.**

Allow Home Assistant to talk to a Z-Wave Network via a USB Controller.

![Supports aarch64 Architecture][aarch64-shield] ![Supports amd64 Architecture][amd64-shield] ![Supports armhf Architecture][armhf-shield] ![Supports armv7 Architecture][armv7-shield] ![Supports i386 Architecture][i386-shield]


[aarch64-shield]: https://img.shields.io/badge/aarch64-yes-green.svg
[amd64-shield]: https://img.shields.io/badge/amd64-yes-green.svg
[armhf-shield]: https://img.shields.io/badge/armhf-yes-green.svg
[armv7-shield]: https://img.shields.io/badge/armv7-yes-green.svg
[i386-shield]: https://img.shields.io/badge/i386-yes-green.svg
